const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const ServerPort2 = new Schema(
  {
    orgname: { type: String },
    orgType: { type: String },
    email: { type: String },
    password: { type: String }
  },
  {
    collection: "plpproject2"
  }
);

module.exports = mongoose.model("ServerPort2", ServerPort2);
