const mongoose= require('mongoose')
const Schema= mongoose.Schema;

const ServerPort = new Schema({
    plang:{type: String},
   skill:{type: String}
},{
    collection: 'userskill'
})

module.exports= mongoose.model('userskill', ServerPort)

