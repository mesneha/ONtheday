import React, { Component } from 'react'
import UserNavComponent from '../../../usernavcomponent';
import axios from "axios";
import { Link } from "react-router-dom";
export class Showexp extends Component {
    constructor() {
        super()
        this.state = { exp: [] }
    
    }
    baseurl = "  http://localhost:3002/addexp";
    getexp = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ exp: response.data })
            console.log(this.state.exp)
        });
    }
    componentDidMount() {
        this.getexp();
    }
    render() {
        return (
            <div>
                <UserNavComponent/><hr/>
                <h2>Expierence Information</h2><br/>
                <h4> {this.state.exp.map((expi) =>
                <div>
                  <h4 key={expi}>
                  <br/>
                  <h4>previous company&nbsp;&nbsp; {expi.prevcompany}&nbsp;&nbsp;<br/>years&nbsp;&nbsp;
                   {expi.years}</h4>
                 
                  </h4>
                </div>
                )
                }
            </h4>
            <br/><br/>
            <hr/>
            <h5> Click  <Link to ="/myprofile"> Here  </Link>to go to previous page</h5>
            </div>
        );
    }
}

export default Showexp
