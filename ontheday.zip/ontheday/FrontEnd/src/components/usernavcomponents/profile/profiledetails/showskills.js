import React, { Component } from 'react'
import UserNavComponent from '../../../usernavcomponent';
import axios from "axios";
import { Link } from "react-router-dom";
export class ShowSkill extends Component {
    constructor() {
        super()
        this.state = { skillset: [] }
    
    }
    baseurl = "  http://localhost:3002/showskill";
    getSkill = () => {
        axios.get(this.baseurl).then((response) => {
            this.setState({ skillset: response.data })
            console.log(this.state.skillset)
        });
    }
    componentDidMount() {
        this.getSkill();
    }
    render() {
        return (
            <div>
                <UserNavComponent/>
                <hr/>
                <h2>My Skills</h2>
                <h4> {this.state.skillset.map((contact) =>
                <div>
                  <h4 key={contact}>
                  <br/>
                  <h4>programming Languages&nbsp;&nbsp; {contact.plang}&nbsp;&nbsp;<br/>skills&nbsp;&nbsp; {contact.skill}</h4>
                 
                  </h4>
                  
                </div>
                )
                }
            </h4>
            <hr/> 
            <h5> Click  <Link to ="/myprofile"> Here  </Link>to go to previous page</h5>

            </div>
        );
    }
}

export default ShowSkill
