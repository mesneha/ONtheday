


import React, {
  Component } from
  "react";
  
  import axios
  from 'axios';
  
  import Card
  from 'react-bootstrap/Card';
  
  import { CardBody,
  CardHeader} from
  'reactstrap';
  
  //  import UserNavComponent from "../../../usernavcomponent";
  
  class UserProfile
  extends Component {
  
  baseurl="http://localhost:3002/Signup"
  
  
  
  constructor(props) {
  
  super(props);
  
  this.state = {
  
  loggedinuser:{ }
  
  
  };
  
  }
  
  getProfile = () => {
  
  axios.get(this.baseurl).then((response) => {
  
  this.setState({
  email: response.data })
  
  console.log(this.state.email)
  
  for(let
  i=0;i<response.data.length;i++){
  
  if(response.data[i].email==sessionStorage.getItem('username')){
  
  this.setState({
  
  loggedinuser:response.data[i]
  
  })
  
  }
  
  }
  
  });
  
  }
  
  componentDidMount() {
  
  this.getProfile();
  
  console.log(this.state.loggedinuser)
  
  }
  
  render() { 
  
  return (
  
  <div>
  
  {/* <UserNavComponent/> */}
  
  <div className="container">
  
  <div className="row">
  
  <div className="col-lg-3">
  
  <Card>
  
  <CardHeader>
 
  <h3 text-align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
  User Profile</h3>
  <img className="img-fluid img-circle" src={require('./pic1.jpg')}
   align="center" width="200px" height="200px"/>
  
  
  <h2>{this.state.loggedinuser.firstname}
  {this.state.loggedinuser.lastname}</h2>
  
  <h4>{this.state.loggedinuser.userType}</h4>
  
  <h4>Email id: 
  {this.state.loggedinuser.email}</h4>
  
  </CardHeader>
  
  
  
  
  </Card>
  
  <br />
  
  
  </div>
  
  <div className="col-lg-6">
  
  <Card>
  
  <CardHeader>
  
  <br/>
  
  <h2 class="glyphicon glyphicon-pencil" > Details </h2><br/>
  
  </CardHeader>
  
  <CardBody>
  
  <a href={'/addskill'}
  className="btn btn-primary "> Add Skill </a>
  
  <br/>
  
  <br/>
  
  <a href ={'/showskill'}
  className="btn btn-info">Show Skill</a>
<br/>
          <br/>
          <a href={'/addexp'}
  className="btn btn-primary ">Add Expierence</a>
  
  <br/>
  
  <br/>

<a href={'/showexp'} className="btn btn-info ">show expiernce</a>
          <br/>
          <br/>
  
  </CardBody>
  
  </Card>
  
  <br />
  
  </div> 
  
  </div>
  
  <br/>
  
  </div> 
  
  <br/>
  
  <br/>
  
  <br/>
  <hr/>
  <footer align="center">
  
  <p><i>
  
  YouJoin Corporation © 2019</i></p>
  
  </footer> 
  
  </div>
  
  );
  
  }
  
  }
  
  
  
  export default
  UserProfile;
  

