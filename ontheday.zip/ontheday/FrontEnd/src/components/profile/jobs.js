import React, { Component } from 'react'
import UserNavComponent from '../usernavcomponent';
import Jobs from '../usernavcomponents/Jobs/Jobs';

export class UserJob extends Component {
    render() {
        const signup = this.props.userData;
        return (
            <div className="backC">
                <UserNavComponent />
              <Jobs/>
            </div>
        )
    }
}

export default UserJob
