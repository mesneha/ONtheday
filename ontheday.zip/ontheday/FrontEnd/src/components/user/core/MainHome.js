import React from "react";


class MainHome extends React.Component {
  render() {
    return (
      <div className="container">
 
        <div className="row">
        <h2 className="text-info" align="center">Welcome To Connectify</h2>
          <div className="row">
          <div className="col-lg-0"></div>
          <div className="col-lg-12">
            <br />
            <br />
            <br />
            <h5 className="text-danger">
            Connectify spent the next two years improving the product, first making it free and ad-supported.
             In 2011, Connectify switched to a freemium commercial model which included premium features for
              paying customers. 
            </h5>

               <img
              src={require("../assets/images/connect.jpg")}
              className="img-fluid"
              width="1200px"
              height="700px"
            />


         
  
        
          </div>
          <div className="col-lg-0">

          </div>
        </div>
        </div>
      </div>
    );
  }
}

export default MainHome;
