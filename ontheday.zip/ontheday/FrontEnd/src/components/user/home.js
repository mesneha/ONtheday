import React, { Component } from 'react'

import NavComponent from '../navcomponent';

export class Home extends Component {
  render() {
    return (
      <div>
           <NavComponent/>
          
         
          
      </div>
    )
  }
}

export default Home
