import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { Redirect } from "react-router";

class Register extends React.Component {
  constructor(props) {
    super(props);
    this.routeChange = this.routeChange.bind(this);
    this.onChangeOrgname = this.onChangeOrgname.bind(this);
    this.onChangeOrgType = this.onChangeOrgType.bind(this);
    this.onChangeEmail = this.onChangeEmail.bind(this);
    this.onChangePassword = this.onChangePassword.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.state = {
      orgname: "",
      orgType: "",
      email: "",
      password: ""
    };
  }
  onChangeOrgname(e) {
    this.setState({
      orgname: e.target.value
    });
  }

  onChangeOrgType(e) {
    this.setState({
      orgType: e.target.value
    });
  }
  onChangeEmail(e) {
    this.setState({
      email: e.target.value
    });
  }

  onChangePassword(e) {
    this.setState({
      password: e.target.value
    });
  }

  routeChange(id) {
    let path = `/LoginOrg`;
    this.props.history.push(path);
  }

  onSubmit(e) {
    e.preventDefault();
    const register = {
      orgname: this.state.orgname,
      orgType: this.state.orgType,
      email: this.state.email,
      password: this.state.password
    };
    console.log(register);
    axios
      .post("http://localhost:3002/register", register)
      .then(function (response) {
        console.log(response.data);
      });
    this.setState({
      name: "",
      status: "",
      redirect: true
    });
  }
  render() {
    const { redirect } = this.state;
    console.log("redirect value" + redirect);
    if (redirect) {
      return <Redirect to="/LoginOrg" />;
    }
    return (
      <div className="container">
        <div>
          <h1 className="text-primary">Make the Connectify to users</h1>
         <hr />

         <div className="row">
            <div className="col-lg-4"></div>

            <div className="col-lg-4">
              <form onSubmit={this.onSubmit}>
                <div className="form-group">
                  <label className="text-primary">
                    {" "}
                    <h3> Company Name </h3>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Company Name"
                    autoFocus
                    value={this.state.orgname}
                    onChange={this.onChangeOrgname}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="text-primary">
                    <h3>Company Type </h3>
                  </label>&nbsp;

                  <select
                    name="company"
                    value={this.state.orgType}
                    onChange={this.onChangeOrgType}
                    required
                  >
                    <option value="IT">      IT</option>
                    <option value="Non-IT">  Non - IT</option>
                    <option value="Research">Research</option>
                    <option value="service"> Service Based</option>
                    <option value="core">    Core Based</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="text-primary">
                    <h3>Email </h3>
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="email"
                    required
                    value={this.state.email}
                    onChange={this.onChangeEmail}
                  />
                </div>

                <div className="form-group">
                  <label className="text-primary">
                    <h3>Password </h3>
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Password"
                    required
                    value={this.state.password}
                    onChange={this.onChangePassword}
                  />
                </div>
                <br />
                <div className="form-group">
                  <input
                    type="submit"
                    value="register"
                    className="btn btn-success" />
                </div>


                <div className="col-lg-4"></div>
              </form>
            </div>
          </div>

        </div>

        <p> Login Directly to Organisation by Clicking<Link to="/LoginOrg"> Here </Link></p>

        <hr />
      </div>
    );
  }
}

export default Register;
